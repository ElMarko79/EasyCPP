#ifndef MAIN
#define MAIN

#include <iostream>
#include <string>
#include <cmath>
#include <list>
#include "prints.h"

#endif